#!/bin/bash
#Yahir Alejandro Navarro Amador

base64 msg.txt
base64 fcfm.png > fcfm.txt
base64 -d mystery_img1.txt > mystery_img1.jpg
base64 -d mystery_img2.txt > mystery_img2.jpg
